﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PTU02_WEBREPORTS.Reports
{
    public static class Hash
    {
        //NO CAMBIAR VALORES DEL HASH, SE USA EN SINCRONIA CON SAP.................................

        public static string[] NumbersArray = new string[10] { "At", "bR", "Cd", "eH", "Pj", "FL", "GY", "yi", "Ij", "Wk" };

        //NO CAMBIAR VALORES DEL HASH, SE USA EN SINCRONIA CON SAP.................................

        public static string HashNumber(string number)
        {
            string result = String.Empty;
            for (int i = 0; i < number.Length; i++)
            {
                result = result + NumbersArray[Int32.Parse(number[i].ToString())];
            }
            return result;
        }

        public static string UnHashNumber(string number)
        {
            string result = "";
            try
            {
                for (int i = 0; i < number.Length; i = i + 2)
                {
                    int numberInteral = int.MinValue;
                    for (int j = 0; j < NumbersArray.Length; j++)
                    {
                        if (number[i].ToString() + number[i + 1].ToString() == NumbersArray[j].ToString())
                        {
                            numberInteral = new int();
                            numberInteral = j;
                            break;
                        }
                    }
                    if (numberInteral != int.MinValue)
                        result = result + numberInteral.ToString();
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Parametros incompletos", ex);
            }
            return result;
        }

    }
}