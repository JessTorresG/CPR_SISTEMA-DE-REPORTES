﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PTU02_WEBREPORTS.Reports
{
    public partial class ActaConstitutiva_CentrosBienestarSocial : System.Web.UI.Page
    {
        string id_caso = "000050000403";

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!Page.IsPostBack)
            //    MultiView1.Visible = true;
            //MultiView1.ActiveViewIndex = 0;
            cargarDatos(id_caso);
        }

        public void cargarDatos(string id_caso)
        {
            Sub_DesarrolloSocial.CallBapi c = new Sub_DesarrolloSocial.CallBapi();
            c.CallFunction_BAPI_CRMPRGCOMITES(id_caso);

            lbl_noProyectop1.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_noProyectop2.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_noProyectop3.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_noProyectop4.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_noProyectop5.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_municipio.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_localidad.Text = Sub_DesarrolloSocial.CallBapi.localidad;
            lbl_descProyecto.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_no_comitep1.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_no_comitep2.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_no_comitep3.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_no_comitep4.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_no_comitep5.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_programa.Text = Sub_DesarrolloSocial.CallBapi.programa;

            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

       

        
    }
}