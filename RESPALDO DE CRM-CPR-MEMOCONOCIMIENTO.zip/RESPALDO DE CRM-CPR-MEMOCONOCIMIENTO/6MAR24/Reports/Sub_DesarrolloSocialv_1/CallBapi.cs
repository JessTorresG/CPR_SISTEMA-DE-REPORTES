﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SAP.Middleware.Connector;

namespace PTU02_WEBREPORTS.Reports.Sub_DesarrolloSocial
{
    public class CallBapi
    {
        string id = "";
        //string id = "000050000385";
        public static string no_proyecto = "";
        public static string municipio = "";
        public static string localidad = "";
        public static string descripcion_proyecto = "";
        public static string programa = "";
        public static string no_comite;

        public CallBapi()
        {
        }

        public void CallFunction_BAPI_CRMPRGCOMITES(string id_caso)
        {
            try
            {
                RfcDestination rfcDest = RfcDestinationManager.GetDestination("SAP_CDV");
                RfcRepository rfcRep = rfcDest.Repository;
                IRfcFunction rfcFun = rfcRep.CreateFunction("ZBAPI_CRMPRGCOMITES");

                rfcFun.SetValue("ID_CASO", id_caso);
                rfcFun.Invoke(rfcDest);

                IRfcTable t_comiteTable = rfcFun.GetTable("T_DATA_COMITE");

                if (t_comiteTable.RowCount > 0)
                {
                    no_proyecto = Convert.ToString(t_comiteTable.GetValue("NO_PROYECTO"));
                    municipio = Convert.ToString(t_comiteTable.GetValue("MUNICIPIO"));
                    localidad = Convert.ToString(t_comiteTable.GetValue("LOCALIDAD"));
                    descripcion_proyecto = Convert.ToString(t_comiteTable.GetValue("DESCRIPCION_PROYECTO"));
                    programa = Convert.ToString(t_comiteTable.GetValue("PROGRAMA"));
                    no_comite = Convert.ToString(t_comiteTable.GetValue("NO_COMITE"));
                }
            }
            catch (Exception ex) { ex.Message.ToString(); }
        }
    }
}