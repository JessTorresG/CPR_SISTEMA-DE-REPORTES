﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ptu02.BO;
using ptu02;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace PTU02_WEBREPORTS.Reports
{
    public partial class ValeMedicamentoUI : System.Web.UI.Page
    {
        private string l_NumID
        {
            get { return this.ViewState["l_NumID"] != null ? this.ViewState["l_NumID"].ToString() : null; }
            set { this.ViewState["l_NumID"] = value; }
        }

        private const int MAXIMO_MEDICAMENTOS = 6;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    l_NumID = Request.QueryString["OBJECT_ID"];

                    
                }
                if (l_NumID != null)
                {
                    #region Seguridad

                    string Corregido = string.Empty;
                    foreach (char item in l_NumID)
                    {
                        if (item != '?')
                            Corregido = Corregido + item;
                    }

                    l_NumID = Corregido;

                    l_NumID = Hash.UnHashNumber(l_NumID);


                    if (l_NumID.Length <= 14)
                    {
                        tbReport.Visible = false;
                        this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "Parametros incorrectos. Genere nuevamente el reporte");
                        return;
                    }
                    string fecha = l_NumID.Substring(0, 14);
                    fecha = fecha.Insert(4, "-").Insert(7, "-").Insert(10, " ").Insert(13, ":").Insert(16, ":");
                    DateTime FechaRecibida = DateTime.MinValue;

                    FechaRecibida = DateTime.Parse(fecha);
                    l_NumID = l_NumID.Substring(14, l_NumID.Length - 14);

                    if (!((DateTime.Now - FechaRecibida).Minutes >= 0 && (DateTime.Now - FechaRecibida).Minutes < Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutValidation"].ToString())))
                    {
                        tbReport.Visible = false;
                        this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "La sesión que intenta abrir ha expirado. Genere nuevamente el reporte");
                        return;
                    }

                    #endregion
                    CargarInformacion();
                }
                else
                {
                    //ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "Error", "alert('La sesión que intenta abrir ha expirado. Genere nuevamente el reporte.'", true);
                    tbReport.Visible = false;
                    this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "Parametros incorrectos. Genere nuevamente el reporte");
                    return;
                }
            }
            catch (System.Exception ex)
            {
                string error = ex.GetBaseException().Message;
                if(ex.Message == "Attempted to divide by zero.")
                    error = "El formato no se puede generar porque hace falta Información de descuento verificar posición";

                tbReport.Visible = false;
                this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", error);
            }            
        }

        private void CargarInformacion()
        {
            ValeMedicamentoViewClass valeMedicamento = Services.ValeMedicamentoReporte(this.l_NumID);
            if (valeMedicamento.Medicamentos.Rows.Count == 0)
                throw new Exception("la petición no cuenta con medicamento alguno para general el vale");

            ValeMedicamentoViewClass[] valeMedicamentoPages = this.CrearGruposImpresion(valeMedicamento);
            for(int i = 0; i < valeMedicamentoPages.Length; i++)
            {
                ValeMedicamentoViewClass subgrupo = valeMedicamentoPages[i];

                TableCell cell1 = new TableCell();
                TableRow row1 = new TableRow();
                row1.Cells.Add(cell1);
                ValeMedicamentoCtrl valeMedicamentoMainCtrl = (ValeMedicamentoCtrl)this.Page.LoadControl("~/Reports/ValeMedicamentoCtrl.ascx");
                this.CargarInformacion(this.l_NumID, subgrupo, valeMedicamentoMainCtrl);
                cell1.Controls.Add(valeMedicamentoMainCtrl);

                TableCell cellLabel = new TableCell();
                TableRow rowLabel = new TableRow();
                rowLabel.Cells.Add(cellLabel);
                HtmlGenericControl labelCopy = new HtmlGenericControl("strong");
                labelCopy.Style.Add("text-transform", "uppercase");
                labelCopy.InnerText = "Copia";
                cellLabel.Controls.Add(labelCopy);

                TableCell cell2 = new TableCell();
                TableRow row2 = new TableRow();
                row2.Cells.Add(cell2);
                ValeMedicamentoCtrl ValeMedicamentoCopy = (ValeMedicamentoCtrl)this.Page.LoadControl("~/Reports/ValeMedicamentoCtrl.ascx");
                this.CargarInformacion(this.l_NumID, subgrupo, ValeMedicamentoCopy);
                cell2.Controls.Add(ValeMedicamentoCopy);

                TableCell cellNumPage = new TableCell();
                cellNumPage.HorizontalAlign = HorizontalAlign.Right;
                TableRow rowNumPage = new TableRow();
                rowNumPage.Cells.Add(cellNumPage);
                HtmlGenericControl labelPage = new HtmlGenericControl("strong");
                labelPage.Style.Add("text-transform", "uppercase");
                labelPage.InnerText = String.Format("Página {0}", i + 1);
                cellNumPage.Controls.Add(labelPage);

                this.tbReport.Rows.AddRange(new TableRow[] {
                    row1,
                    rowLabel,
                    row2,
                    rowNumPage
                });                
            }           
        }

        private ValeMedicamentoViewClass[] CrearGruposImpresion(ValeMedicamentoViewClass valeMedicamento)
        {
            List<ValeMedicamentoViewClass> grupos = new List<ValeMedicamentoViewClass>();            
            int parts = Convert.ToInt32(Math.Ceiling((Decimal)valeMedicamento.Medicamentos.Rows.Count / (Decimal)ValeMedicamentoUI.MAXIMO_MEDICAMENTOS));

            for (int i = 0; i < parts; i++)
            {
                int li = i * ValeMedicamentoUI.MAXIMO_MEDICAMENTOS;
                int ls = Math.Min(li + ValeMedicamentoUI.MAXIMO_MEDICAMENTOS, valeMedicamento.Medicamentos.Rows.Count);

                ValeMedicamentoViewClass newInstance = valeMedicamento.Clone();
                newInstance.Medicamentos.Clear();
                for (int p = li; p < ls; p++)
                    newInstance.Medicamentos.ImportRow(valeMedicamento.Medicamentos.Rows[p]);

                grupos.Add(newInstance);
            }            

            return grupos.ToArray();
        }

        private void CargarInformacion(String folio, ValeMedicamentoViewClass valeMedicamento, ValeMedicamentoCtrl ctrl)
        {
            ctrl.lbl_VigenciaHastaText = valeMedicamento.VigenciaHasta.Value.ToString("dd/MM/yyyy");
            ctrl.lbl_FechaImpresionText = valeMedicamento.FechaImpresion.Value.ToString("dd/MM/yyyy");
            ctrl.lbl_FolioText = folio;

            ctrl.Partner2 = valeMedicamento.Partner2;
            ctrl.Partner2_ADRC = valeMedicamento.Partner2_ADR;

            ctrl.ltrl_BeneficiarioText = valeMedicamento.Beneficiario;

            ctrl.lbl_CalleYNuneroText = (String.IsNullOrEmpty(valeMedicamento.CalleYNumero))?"&nbsp;":valeMedicamento.CalleYNumero;
            ctrl.lbl_ColoniaText = (String.IsNullOrEmpty(valeMedicamento.Colonia)) ? "&nbsp;" : valeMedicamento.Colonia;
            ctrl.lbl_EstadoText = (String.IsNullOrEmpty(valeMedicamento.Estado)) ? "&nbsp;" : valeMedicamento.Estado;
            ctrl.lbl_MunicipioText = (String.IsNullOrEmpty(valeMedicamento.Municipio)) ? "&nbsp;" : valeMedicamento.Municipio;

            ctrl.rptMedicamentosDataSource = valeMedicamento.Medicamentos;

            ctrl.Firm_SecretarioSalud = valeMedicamento.Firm_SecretarioSalud;
            ctrl.Firm_SecretarioSecretarioSalud = valeMedicamento.Firm_SecretarioSecretarioSalud;
            ctrl.Firm_JefeDepto = valeMedicamento.Firm_JefeDepto;
        }
    }
}