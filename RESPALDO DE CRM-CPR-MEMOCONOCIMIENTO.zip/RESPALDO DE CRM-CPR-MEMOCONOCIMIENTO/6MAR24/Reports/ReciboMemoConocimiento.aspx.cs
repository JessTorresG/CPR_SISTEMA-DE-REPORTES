﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ptu02.BO;
using ptu02;
using System.Configuration;


namespace PTU02_WEBREPORTS.Reports
{
    public partial class ReciboMemoConocimiento : System.Web.UI.Page 
    {


        public String DocumentID
        {
            get;
            set;
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                DocumentID = this.Request.QueryString["OBJECT_ID"];

                if (!this.IsPostBack && this.DocumentID != null)
                {
                    #region Seguridad

                    string Corregido = string.Empty;
                    foreach (char item in DocumentID)
                    {
                        if (item != '?')
                            Corregido = Corregido + item;
                    }

                    DocumentID = Corregido;
                    DocumentID = Hash.UnHashNumber(DocumentID);
                    //INICIO COMENTANDO ERROR JETORRESG
                    if (DocumentID.Length <= 14)
                    {
                        tbl_datos.Visible = false;
                        //this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "Parametros incorrectos. Genere nuevamente el reporte");
                        return;
                     }
                        string fecha = DocumentID.Substring(0, 14);
                    fecha = fecha.Insert(4, "-").Insert(7, "-").Insert(10, " ").Insert(13, ":").Insert(16, ":");
                    DateTime FechaRecibida = DateTime.MinValue;

                    FechaRecibida = DateTime.Parse(fecha);
                    DocumentID = DocumentID.Substring(14, DocumentID.Length - 14);

                    //INICIO COMENTANDO ERROR JETORRESG
                    if (!((DateTime.Now - FechaRecibida).Minutes >= 0 && (DateTime.Now - FechaRecibida).Minutes < Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutValidation"].ToString())))
                    {
                        tbl_datos.Visible = false;
                        //this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "La sesión que intenta abrir ha expirado. Genere nuevamente el reporte");
                        return;
                    }
                    //FIN

                    #endregion

                    this.CargarInformacion();

                }
                else
                {
                    //COMENTANDO ERROR JETORRESG
                    tbl_datos.Visible = false;
                    //this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "Parametros incorrectos. Genere nuevamente el reporte");
                    return;
                }
            }
            catch (Exception ex)
            {
                //COMENTANDO ERROR JETORRESG
                tbl_datos.Visible = false;
                //this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", ex.Message);
                return;
            }
        }

        private void CargarInformacion()
        {
            ReciboMemoConocimientoViewClass bo = Services.ReporteReciboMemoConocimiento(this.DocumentID);

            //this.lbl_Fecha.Text = DateTime.Now.ToLongDateString();
            //this.lbl_Fecha_Recepcion.Text = DateTime.Now.ToLongDateString();
            this.lbl_Ciudadano.Text = bo.Beneficiario;
            this.lbl_MunicipioBP.Text = bo.MunicipioBP;
            this.lbl_Fecha.Text = DateTime.Now.ToString("MMMM") + " " + DateTime.Now.ToString("dd") + ", " + DateTime.Now.ToString("yyyy") + " ";

            this.lbl_Tel_BP.Text = bo.Tel_BP;
            this.lbl_CorreoBP.Text = bo.CorreoBP;

            //this.lbl_Asunto.Text = bo.AsuntoBP;
            //this.lbl_asunto = bo.Obj_id;
            //this.lbl_ccp.Text = bo.ConCopia;

            //this.Lbl_Solicitud.Text = bo.NoSolicitud;
            this.lbl_Beneficiario.Text = "En atención a su solicitud dirigida al C. Gobernador, la cual se derivara para conocimiento " +
                    "y atención mediante el folio " +
                    "<span class='campo_2'> " + bo.NoSolicitud + " </span>,  " +
                    "de fecha" + "<span class='campo_2'> " + bo.FechaRecepcion.ToLongDateString() + " </span>, " +
                    "con Asunto: "+ "<span class='campo_2'>" + bo.AsuntoBP + " </span>." +
                    " Me permito informar que fué remitida a la " +
                    "<span class='campo 2'>" + bo.Dependencia + " </span>, " +                  
                    "quien es la instancia competente para determinar la viabilidad de su requerimiento y otorgarle una respuesta.<br /><br /> " +
                    "Para mayor información puede comunicarse al teléfono 800-6-33-33-33, en un horario de 8:00 a.m. a 8:00 p.m. de Lunes a Viernes.";

        }
    }
}