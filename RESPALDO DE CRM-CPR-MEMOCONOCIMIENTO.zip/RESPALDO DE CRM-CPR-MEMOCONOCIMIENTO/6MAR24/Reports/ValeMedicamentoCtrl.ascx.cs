﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PTU02_WEBREPORTS.Reports
{
    public partial class ValeMedicamentoCtrl : System.Web.UI.UserControl
    {
        public String lbl_VigenciaHastaText
        {
            get { return this.lbl_VigenciaHasta.Text; }
            set { this.lbl_VigenciaHasta.Text = value; }
        }

        public String lbl_FechaImpresionText
        {
            get { return this.lbl_FechaImpresion.Text; }
            set { this.lbl_FechaImpresion.Text = value; }
        }

        public String lbl_FolioText
        {
            get { return this.lbl_Folio.Text; }
            set { this.lbl_Folio.Text = value; }
        }

        public String ltrl_BeneficiarioText
        {
            get { return this.ltrl_Beneficiario.Text; }
            set { this.ltrl_Beneficiario.Text = value; }
        }

        public String lbl_CalleYNuneroText
        {
            get { return this.lbl_CalleYNunero.Text; }
            set { this.lbl_CalleYNunero.Text = value; }
        }

        public String lbl_ColoniaText
        {
            get { return this.lbl_Colonia.Text; }
            set { this.lbl_Colonia.Text = value; }
        }

        public String lbl_EstadoText
        {
            get { return this.lbl_Estado.Text; }
            set { this.lbl_Estado.Text = value; }
        }

        public String lbl_MunicipioText
        {
            get { return this.lbl_Municipio.Text; }
            set { this.lbl_Municipio.Text = value; }
        }

        public Object rptMedicamentosDataSource
        {
            get { return this.rptMedicamentos.DataSource; }
            set
            {
                this.rptMedicamentos.DataSource = value;
                this.rptMedicamentos.DataBind();
            }
        }

        public String Firm_SecretarioSalud
        {
            get { return this.lbl_Firm_SecretarioSalud.Text; }
            set { this.lbl_Firm_SecretarioSalud.Text = value; }
        }

        public String Firm_SecretarioSecretarioSalud
        {
            get { return this.lbl_Firm_SecretarioSecretarioSalud.Text; }
            set { this.lbl_Firm_SecretarioSecretarioSalud.Text = value; }
        }

        public String Firm_JefeDepto
        {
            get { return this.lbl_Firm_JefeDepto.Text; }
            set { this.lbl_Firm_JefeDepto.Text = value; }
        }

        public String Partner2
        {
            get { return this.lbl_Partner2.Text; }
            set { this.lbl_Partner2.Text = value; }
        }

        public String Partner2_ADRC
        {
            get { return this.lbl_Partner2_ADRC.Text; }
            set { this.lbl_Partner2_ADRC.Text = value; }
        }

    }
}