﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PTU02_WEBREPORTS.Reports.Sub_DesarrolloSocial
{
    public partial class ListaActas : System.Web.UI.Page
    {
        public string id_caso = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            id_caso = Request.QueryString["ID"];
            
            //Response.Write("El valor del id_caso es: " + id_caso.ToString());

            Session["id_caso"] =  id_caso;
        }
    }
}