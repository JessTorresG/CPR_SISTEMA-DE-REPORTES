﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PTU02_WEBREPORTS
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
                lbl_Status.Visible = false;
        }

        protected void btn_FondoDIF_Click(object sender, EventArgs e)
        {
            string imagen = ((System.Web.UI.Control)(sender)).ID.Substring(4);
            FileUpload fup = new FileUpload();

            switch (imagen)
            {
                case "Tamaulipas_gobierno_2":
                    fup = this.fup_Tamaulipas_gobierno_2;
                    break;
                case "Tamaulipas_gobierno":
                    fup = this.fup_Tamaulipas_gobierno;
                    break;
                case "FondoDIF":
                    fup = this.fup_FondoDIF;
                    break;
                case "logo_DIF":
                    fup = this.fup_logo_DIF;
                    break;
                case "Tamaulipas_fuerte":
                    fup = this.fup_Tamaulipas_fuerte;
                    break;
                case "Tamaulipas_fuerte_2":
                    fup = this.fup_Tamaulipas_fuerte_2;
                    break;
                case "Tamaulipas_fuerte_MED":
                    fup = this.fup_Tamaulipas_fuerte_MED;
                    break;
                case "Tamaulipas_gobierno_MED":
                    fup = this.fup_Tamaulipas_gobierno_MED;
                    break;
                default:
                    lbl_Status.Text = "Estatus: Error al subir el archivo!";
                    break;
            }

            if (fup.HasFile)
            {
                try
                {
                    if (fup.PostedFile.ContentType == "image/jpeg" ||
                        fup.PostedFile.ContentType == "image/x-png")
                    {
                        if (fup.PostedFile.ContentLength < 102400)
                        {
                            string filename = imagen + ".jpg";
                            fup.SaveAs(Server.MapPath("~/") + "App_Themes/Default/images/" + filename);
                            lbl_Status.Text = "Estatus: Archivo Actualizado!";
                        }
                        else
                            lbl_Status.Text = "Estatus: Archivo muy grande para actualizar!";
                    }
                    else
                        lbl_Status.Text = "Estatus: Solo se aceptan archivos tipo imagen .jpg!";
                }
                catch (Exception ex)
                {
                    lbl_Status.Text = "Estatus: El archivo no pudo subirse, por el siguiente error: " + ex.Message;
                }
            }
            else
                lbl_Status.Text = "Estatus: No se tiene un archivo seleccionado";

            lbl_Status.Visible = true;
        }
    }
}