﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ptu02.BO;
using ptu02;
using System.Configuration;

namespace PTU02_WEBREPORTS.Reports
{
    public partial class ReciboMemo : System.Web.UI.Page
    {
        public String DocumentID
        {
            get;
            set; 
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                DocumentID = this.Request.QueryString["OBJECT_ID"];

                if (!this.IsPostBack && this.DocumentID != null)
                {

                    #region Seguridad

                    string Corregido = string.Empty;
                    foreach (char item in DocumentID)
                    {
                        if (item != '?')
                            Corregido = Corregido + item;
                    }

                    DocumentID = Corregido;
                    DocumentID = Hash.UnHashNumber(DocumentID);
                    if (DocumentID.Length <= 14)
                    {
                        tbl_datos.Visible = false;
                        this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "Parametros incorrectos. Genere nuevamente el reporte");
                        return;
                    }
                    string fecha = DocumentID.Substring(0, 14);
                    fecha = fecha.Insert(4, "-").Insert(7, "-").Insert(10, " ").Insert(13, ":").Insert(16, ":");
                    DateTime FechaRecibida = DateTime.MinValue;

                    FechaRecibida = DateTime.Parse(fecha);
                    DocumentID = DocumentID.Substring(14, DocumentID.Length - 14);
              

                    if (!((DateTime.Now - FechaRecibida).Minutes >= 0 && (DateTime.Now - FechaRecibida).Minutes < Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutValidation"].ToString())))
                    {
                        tbl_datos.Visible = false;
                        this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "La sesión que intenta abrir ha expirado. Genere nuevamente el reporte");
                        return;
                    }

                    #endregion

                    this.CargarInformacion();
                }
                else
                {
                    tbl_datos.Visible = false;
                    this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "Parametros incorrectos. Genere nuevamente el reporte");
                    return;
                }
            }
            catch (Exception ex)
            {
                tbl_datos.Visible = false;
                this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", ex.Message);
                return;
            }
        }

        private void CargarInformacion()
        {
            ReciboMemoViewClass bo = Services.ReporteReciboMemo(this.DocumentID);

            this.lblMemoNo.Text = bo.NoSolicitud;
            //this.lblBeneficiario.Text = bo.Beneficiario;
            //this.lblConcepto.Text = bo.Concepto;
            //this.lblCantidad.Text = bo.Cantidad.ToString() + " " + bo.cantidadLetras;
            //this.lblDomicilio.Text = bo.Direccion;
            //this.lbl_DirectorOficinasEjecutivoEstatalNombre.Text = bo.DirectorOficinasEjecutivoEstatalNombre;

            this.lblFecha.Text = bo.Fecha.ToShortDateString();
            this.lblTipoApoyo.Text = bo.TipoDeApoyo;

            //this.lbl_DirGenRelaciones.Text = bo.lbl_DirGenRelaciones;

            this.lbl_Beneficiario.Text = "Por este conducto me permito solicitar a Usted apoyo para " +
                    "<span class='campo_2'> " + bo.Beneficiario + " </span>, con " +
                    "la cantidad de $ " +
                    "<span class='campo_2' >" + bo.Cantidad.ToString() + " (" + bo.cantidadLetras + ") </span> " +
                    "por concepto de " +
                    "<span class='campo_2' >" + bo.Concepto + " </span> " +
                    "manifestando no contar con los recursos económicos y tener su domicilio en: " +
                    "<span class='campo_2' >" + bo.Direccion + " </span>.";
        }
    }
}