﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PTU02_WEBREPORTS.Reports
{
    public partial class ActaConstitutiva_ObraItife : System.Web.UI.Page
    {
        string id_caso = "";
        string id = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            id = Session["id_caso"].ToString();
            id_caso = "0000" + id;
            cargarDatos(id_caso);
        }

        public void cargarDatos(string id_caso)
        {
            Sub_DesarrolloSocial.CallBapi c = new Sub_DesarrolloSocial.CallBapi();
            c.CallFunction_BAPI_CRMPRGCOMITES(id_caso);

            lbl_noProyectop1.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_noProyectop2.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_noProyectop3.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_noProyectop4.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_noProyectop5.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_municipio.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_localidad.Text = Sub_DesarrolloSocial.CallBapi.localidad;
            lbl_descProyecto.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_no_comitep1.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_no_comitep2.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_no_comitep3.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_no_comitep4.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_no_comitep5.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_programa.Text = Sub_DesarrolloSocial.CallBapi.programa;

            //Llenar los labels de Registro Familiar.

            lbl_noComite_rf1.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_municipio_rf1.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa_rf1.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcionProyecto_rf1.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_noProyecto_rf1.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_localidad_rf1.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_noComite_rf2.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_municipio_rf2.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa_rf2.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcionProyecto_rf2.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_noProyecto_rf2.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_localidad_rf2.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_noComite_rf3.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_municipio_rf3.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa_rf3.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcionProyecto_rf3.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_noProyecto_rf3.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_localidad_rf3.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_noComite_rf4.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_municipio_rf4.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa_rf4.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcionProyecto_rf4.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_noProyecto_rf4.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_localidad_rf4.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_noComite_rf5.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_municipio_rf5.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa_rf5.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcionProyecto_rf5.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_noProyecto_rf5.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_localidad_rf5.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_noComite_rf6.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_municipio_rf6.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa_rf6.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcionProyecto_rf6.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_noProyecto_rf6.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_localidad_rf6.Text = Sub_DesarrolloSocial.CallBapi.localidad;
        }

        protected void btn_imprimir_Click(object sender, EventArgs e)
        {

        }

   
        
    }
}