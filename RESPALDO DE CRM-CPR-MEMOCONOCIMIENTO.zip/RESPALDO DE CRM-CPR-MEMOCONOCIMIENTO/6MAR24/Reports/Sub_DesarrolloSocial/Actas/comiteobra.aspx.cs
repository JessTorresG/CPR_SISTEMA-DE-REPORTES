﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PTU02_WEBREPORTS.Reports.Actas
{
    public partial class comiteobra : System.Web.UI.Page
    {
        public string id = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            char pad = '0';
            id = Session["id_caso"].ToString();
            id = id.PadLeft(12, pad);
            cargarDatos(id);
        }

        public void cargarDatos(string id_caso)
        {
            Sub_DesarrolloSocial.CallBapi c = new Sub_DesarrolloSocial.CallBapi();
            c.CallFunction_BAPI_CRMPRGCOMITES(id_caso);

            lbl_year.Text = c.SystemYear();
            lbl_comite1.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_comite2.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_comite3.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_comite4.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_comite5.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_comite6.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_comite7.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_comite8.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_comite9.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_comite10.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_comite11.Text = Sub_DesarrolloSocial.CallBapi.no_comite;

            lbl_proyecto1.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_proyecto2.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_proyecto3.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_proyecto4.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_proyecto5.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_proyecto6.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_proyecto7.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_proyecto8.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_proyecto9.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_proyecto10.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_proyecto11.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;


            //Llenar los labels de Registro Familiar.
            lbl_municipio1.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa1.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcion1.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_localidad1.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_municipio2.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa2.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcion2.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_localidad2.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_municipio3.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa3.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcion3.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_localidad3.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_municipio4.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa4.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcion4.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_localidad4.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_municipio5.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa5.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcion5.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_localidad5.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_municipio6.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa6.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcion6.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_localidad6.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_municipio7.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa7.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcion7.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_localidad7.Text = Sub_DesarrolloSocial.CallBapi.localidad;
        }
    }
}