﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SAP.Middleware.Connector;
using System.Configuration;
using System.Globalization;
using System.Collections;

namespace PTU02_WEBREPORTS.Reports.Sub_DesarrolloSocial
{
    public partial class gafete1 : System.Web.UI.Page
    {
        DateTimeFormatInfo formatoFecha = CultureInfo.CurrentCulture.DateTimeFormat;
        public string id_caso = "";
        //string id = "";
        public DataTable dt_ciudadano;
        public DataTable dt_comite;
        public int i = 0;
 
        Sub_DesarrolloSocial.CallBapi c = new Sub_DesarrolloSocial.CallBapi();

        protected void Page_Load(object sender, EventArgs e)
        {
           
            id_caso = Request.QueryString["ID"];

                    char pad = '0';
                    id_caso = id_caso.PadLeft(12, pad).ToString();

                if (!Page.IsPostBack)
                {
                    
                    //Response.Write("El valor del id_caso es: " + id_caso.ToString());
                }

                if (id_caso != null)
                {
                    tablesGafetes();
                    
                }
                
        }

        public void cargarControles()
        {
            //c.IntegrantesComite(id_caso);
            //c.CallFunction_BAPI_CRMPRGCOMITES(id_caso);

            //lbl_nombre.Text = c.nombre_ciudadano.ToUpper();
            //lbl_puesto.Text = c.puesto.ToUpper();
            //lbl_municipio.Text = CallBapi.municipio.ToUpper();
            //lbl_apertura.Text = c.nombre_comite.ToUpper();
            //lbl_descProyect.Text = CallBapi.descripcion_proyecto;

            //lbl_nombre.Text = c.nombre_ciudadano.ToUpper();
            //lbl_puesto.Text = c.puesto.ToUpper();
            //lbl_municipio.Text = CallBapi.municipio.ToUpper();
            //lbl_apertura.Text = c.nombre_comite.ToUpper();
            //lbl_descProyect.Text = CallBapi.descripcion_proyecto;

            //lbl_mes.Text = formatoFecha.GetMonthName(DateTime.Now.Month).ToUpper();
            //lbl_año.Text = Convert.ToString(DateTime.Now.Year);
            //lbl_año.Text = formatoFecha.GetMonthName(Convert.ToInt32(DateTime.Now.Year));
          

            //if (c.nombre_ciudadano == null)
            //{
            //    lbl_nombre.Text = "SIN NOMBRE";
            //}

            //if (c.puesto == "")
            //{
            //    lbl_puesto.Text = "SIN PUESTO";
            //}
        }

        public static DataTable GetDataTableFromRFCTable(IRfcTable lrfcTable)
        {
            //sapnco_util
            DataTable loTable = new DataTable();

            //... Create ADO.Net table.
            for (int liElement = 0; liElement < lrfcTable.ElementCount; liElement++)
            {
                RfcElementMetadata metadata = lrfcTable.GetElementMetadata(liElement);
                loTable.Columns.Add(metadata.Name);
            }

            //... Transfer rows from lrfcTable to ADO.Net table.
            foreach (IRfcStructure row in lrfcTable)
            {
                DataRow ldr = loTable.NewRow();
                for (int liElement = 0; liElement < lrfcTable.ElementCount; liElement++)
                {
                    RfcElementMetadata metadata = lrfcTable.GetElementMetadata(liElement);
                    ldr[metadata.Name] = row.GetString(metadata.Name);
                }
                loTable.Rows.Add(ldr);
            }

            return loTable;
        }

        public void tablaCiudadano()
        {
            RfcDestination rfcDest = RfcDestinationManager.GetDestination("SAP_CPR");
            RfcRepository rfcRep = rfcDest.Repository;
            IRfcFunction rfcFun = rfcRep.CreateFunction("Z_BAPIPRGCOMITES");

            rfcFun.SetValue("ID_CASO",id_caso);
            RfcSessionManager.BeginContext(rfcDest);
            rfcFun.Invoke(rfcDest);

            IRfcTable t_ciudadanoTable = rfcFun.GetTable("T_DATA_CIUDADANO");
            IRfcTable t_comiteTable = rfcFun.GetTable("T_DATA_COMITE");
            dt_ciudadano = GetDataTableFromRFCTable(t_ciudadanoTable);
            dt_comite = GetDataTableFromRFCTable(t_comiteTable);

            for (int i = 0; i < Convert.ToInt16(dt_ciudadano.Rows.Count); i++)
            {
                //lbl_nombre.Text = dt_ciudadano.Rows[i]["NOMBRE_RESPONSABLE"].ToString();
                //lbl_puesto.Text = dt_ciudadano.Rows[i]["PUESTO"].ToString();

                Response.Write(dt_ciudadano.Rows[i]["NOMBRE_RESPONSABLE"].ToString());
            }

            //Response.Write(dt_ciudadano);
            //GridView1.DataSource = dt;
            //GridView2.DataSource = dt2;
            //GridView1.DataBind();
            //GridView2.DataBind();
        }

        public void tablesGafetes()
        {
            RfcDestination rfcDest = RfcDestinationManager.GetDestination("SAP_CPR");
            RfcRepository rfcRep = rfcDest.Repository;
            IRfcFunction rfcFun = rfcRep.CreateFunction("Z_BAPIPRGCOMITES");
            
            rfcFun.SetValue("ID_CASO", id_caso);
            RfcSessionManager.BeginContext(rfcDest);
            rfcFun.Invoke(rfcDest);

            IRfcTable t_ciudadanoTable = rfcFun.GetTable("T_DATA_CIUDADANO");
            IRfcTable t_comiteTable = rfcFun.GetTable("T_DATA_COMITE");
            dt_ciudadano = GetDataTableFromRFCTable(t_ciudadanoTable);
            dt_comite = GetDataTableFromRFCTable(t_comiteTable);

            if (dt_ciudadano.Rows.Count == 0)
            { 
                Response.Write("<script> window.alert('No se encontraron datos de los ciudadanos');</script>");
                ClientScript.RegisterStartupScript(this.GetType(), "myScript", "<script>window.close();</script>");
            }else
                if (dt_comite.Rows.Count == 0)
                {
                    Response.Write("<script> window.alert('No se encontraron datos del comite');</script>");
                    ClientScript.RegisterStartupScript(this.GetType(), "myScript", "<script>window.close();</script>");
                }
                else
                {
                    Repeater1.DataSource = dt_ciudadano;
                    Repeater1.DataBind();
                    
                }
        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            string nombre, puesto, municipio;
            string descProyect;
            string url;
            string apertura;

            nombre = dt_ciudadano.Rows[i]["NOMBRE_RESPONSABLE"].ToString();
            puesto = dt_ciudadano.Rows[i]["PUESTO"].ToString();
            municipio = dt_comite.Rows[0]["MUNICIPIO"].ToString();
            apertura = dt_comite.Rows[0]["NOMBRE_COMITE"].ToString();
            descProyect = dt_comite.Rows[0]["DESCRIPCION_PROYECTO"].ToString();
            url = dt_ciudadano.Rows[i]["URL"].ToString();
            
            //Crear controles
            Label lbl_nombre = default(Label);
            Label lbl_puesto=default(Label);
            Label lbl_año = default(Label);
            Label lbl_mes = default(Label);
            Label lbl_municipio = default(Label);
            Label lbl_descProyect = default(Label);
            Label lbl_apertura = default(Label);
            Image img_ciudadano = default(Image);

            lbl_nombre = (Label)e.Item.FindControl("lbl_nombre");
            lbl_puesto = (Label)e.Item.FindControl("lbl_puesto");
            lbl_municipio = (Label)e.Item.FindControl("lbl_municipio");
            lbl_año = (Label)e.Item.FindControl("lbl_año");
            lbl_mes = (Label)e.Item.FindControl("lbl_mes");
            lbl_descProyect = (Label)e.Item.FindControl("lbl_descProyect");
            lbl_apertura = (Label)e.Item.FindControl("lbl_apertura");
            img_ciudadano = (Image)e.Item.FindControl("foto");


            //Asignar valores a los controles:
            lbl_nombre.Text = nombre;
            lbl_puesto.Text = puesto;
            lbl_municipio.Text = municipio;
            lbl_descProyect.Text = descProyect;
            lbl_apertura.Text = apertura;
            lbl_mes.Text = formatoFecha.GetMonthName(DateTime.Now.Month).ToUpper();
            lbl_año.Text = Convert.ToString(DateTime.Now.Year);

            if (url == "")
            { img_ciudadano.ImageUrl = "~/App_Themes/Default/images/fotodemo.jpg"; }
            else
            { img_ciudadano.ImageUrl = url; }

            if (puesto == "")
            {lbl_puesto.Text = "SIN PUESTO";}
            else
                if (nombre == "")
                {lbl_nombre.Text = "SIN NOMBRE";}
                else
                    if (municipio == "")
                    { lbl_municipio.Text = "SIN MUNICIPIO"; }
                    else
                        if (apertura == "")
                        { lbl_apertura.Text = "SIN APERTURA"; }
                        else
                        if (descProyect == "")
                        { lbl_descProyect.Text = "SIN DESCRIPCION"; }
            i++;
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

        }
    }
}