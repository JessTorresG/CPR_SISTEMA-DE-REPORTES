﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using SAP.Middleware.Connector;

namespace PTU02_WEBREPORTS.Reports
{
    public partial class ActaConstitutiva_ComiteObra: System.Web.UI.Page
    {
        string id_caso = "";
        string id = "";
       
        protected void Page_Load(object sender, EventArgs e)
        {
            id = Session["id_caso"].ToString();
            id_caso = "0000" + id;
            cargarDatos(id_caso);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           
        }

        //public void CallFunction_BAPI_CRMPRGCOMITES(string id)
        //{
        //    try
        //    {
        //        RfcDestination rfcDest = RfcDestinationManager.GetDestination("SAP_CDV");
        //        RfcRepository rfcRep = rfcDest.Repository;
        //        IRfcFunction rfcFun = rfcRep.CreateFunction("ZBAPI_CRMPRGCOMITES");

        //        rfcFun.SetValue("ID_CASO", id);
        //        rfcFun.Invoke(rfcDest);

        //        IRfcTable t_comiteTable = rfcFun.GetTable("T_DATA_COMITE");
        //        //IRfcStructure t_productosStructure = t_comiteTable.Metadata.LineType.CreateStructure();
        //        //lbl_no_comite.Text = "ok";

        //        if (t_comiteTable.RowCount > 0)
        //        {
        //            no_proyecto = Convert.ToString(t_comiteTable.GetValue("NO_PROYECTO"));
        //            municipio = Convert.ToString(t_comiteTable.GetValue("MUNICIPIO"));
        //            localidad = Convert.ToString(t_comiteTable.GetValue("LOCALIDAD"));
        //            descripcion_proyecto = Convert.ToString(t_comiteTable.GetValue("DESCRIPCION_PROYECTO"));
        //            programa = Convert.ToString(t_comiteTable.GetValue("PROGRAMA"));                

        //            no_comite = Convert.ToString(t_comiteTable.GetValue("NO_COMITE"));
        //            lbl_noProyectop1.Text = no_proyecto;
        //            lbl_noProyectop2.Text = no_proyecto;
        //            lbl_noProyectop3.Text = no_proyecto;
        //            lbl_noProyectop4.Text = no_proyecto;
        //            lbl_noProyectop5.Text = no_proyecto;
        //            lbl_municipio.Text = municipio;
        //            lbl_localidad.Text = localidad;
        //            lbl_descProyecto.Text = descripcion_proyecto;
        //            lbl_no_comitep1.Text = no_comite;
        //            lbl_no_comitep2.Text = no_comite;
        //            lbl_no_comitep3.Text = no_comite;
        //            lbl_no_comitep4.Text = no_comite;
        //            lbl_no_comitep5.Text = no_comite;
        //            lbl_programa.Text = programa;

        //            //no_proyecto = t_comiteTable.GetString("NO_PROYECTO").ToString();
        //            //municipio = t_comiteTable.GetString("MUNICIPIO").ToString();
        //            //localidad = t_comiteTable.GetString("LOCALIDAD").ToString();
        //            //descripcion_proyecto = t_comiteTable.GetString("DESCRIPCION_PROYECTO").ToString();
        //            //programa = t_comiteTable.GetString("PROGRAMA").ToString();
        //            //lbl_no_comite.Text = t_comiteTable.GetString("NO_COMITE").ToString();
        //        }

        //        //RfcSessionManager.BeginContext(rfcDest);
        //        //rfcFun.Invoke(rfcDest);
        //        //RfcSessionManager.EndContext(rfcDest);


        //    }
        //    catch (Exception ex) { Response.Write(ex.Message.ToString()); }
        //}

        public void cargarDatos(string id_caso)
        {
            Sub_DesarrolloSocial.CallBapi c = new Sub_DesarrolloSocial.CallBapi();
            c.CallFunction_BAPI_CRMPRGCOMITES(id_caso);

            lbl_noProyectop1.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_noProyectop2.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_noProyectop3.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_noProyectop4.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_noProyectop5.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_municipio.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_localidad.Text = Sub_DesarrolloSocial.CallBapi.localidad;
            lbl_descProyecto.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_no_comitep1.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_no_comitep2.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_no_comitep3.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_no_comitep4.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_no_comitep5.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_programa.Text = Sub_DesarrolloSocial.CallBapi.programa;

            //Llenar los labels de Registro Familiar.

            lbl_noComite_rf1.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_municipio_rf1.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa_rf1.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcionProyecto_rf1.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_noProyecto_rf1.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_localidad_rf1.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_noComite_rf2.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_municipio_rf2.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa_rf2.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcionProyecto_rf2.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_noProyecto_rf2.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_localidad_rf2.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_noComite_rf3.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_municipio_rf3.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa_rf3.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcionProyecto_rf3.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_noProyecto_rf3.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_localidad_rf3.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_noComite_rf4.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_municipio_rf4.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa_rf4.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcionProyecto_rf4.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_noProyecto_rf4.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_localidad_rf4.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_noComite_rf5.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_municipio_rf5.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa_rf5.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcionProyecto_rf5.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_noProyecto_rf5.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_localidad_rf5.Text = Sub_DesarrolloSocial.CallBapi.localidad;

            lbl_noComite_rf6.Text = Sub_DesarrolloSocial.CallBapi.no_comite;
            lbl_municipio_rf6.Text = Sub_DesarrolloSocial.CallBapi.municipio;
            lbl_programa_rf6.Text = Sub_DesarrolloSocial.CallBapi.programa;
            lbl_descripcionProyecto_rf6.Text = Sub_DesarrolloSocial.CallBapi.descripcion_proyecto;
            lbl_noProyecto_rf6.Text = Sub_DesarrolloSocial.CallBapi.no_proyecto;
            lbl_localidad_rf6.Text = Sub_DesarrolloSocial.CallBapi.localidad;
        }
    }
}