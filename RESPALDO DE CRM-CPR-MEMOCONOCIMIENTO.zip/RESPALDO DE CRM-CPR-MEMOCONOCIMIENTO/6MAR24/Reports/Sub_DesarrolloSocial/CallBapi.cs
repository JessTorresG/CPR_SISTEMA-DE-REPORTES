﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SAP.Middleware.Connector;

namespace PTU02_WEBREPORTS.Reports.Sub_DesarrolloSocial
{
    public class CallBapi
    {
        //string id = "";
        //string id = "000050000385";
        public static string no_proyecto = "";
        public static string municipio = "";
        public static string localidad = "";
        public static string descripcion_proyecto = "";
        public static string programa = "";
        public static string no_comite;
        public string nombre_comite;

        public string nombre_ciudadano;
        //public string[] nombre_ciudadano;
        public string puesto;
        //public string apertura;

        public CallBapi()
        {
        }

        public void CallFunction_BAPI_CRMPRGCOMITES(string id_caso)
        {
            try
            {
                RfcDestination rfcDest = RfcDestinationManager.GetDestination("SAP_CPR");
                RfcRepository rfcRep = rfcDest.Repository;
                IRfcFunction rfcFun = rfcRep.CreateFunction("Z_BAPIPRGCOMITES");

                rfcFun.SetValue("ID_CASO", id_caso);
                rfcFun.Invoke(rfcDest);

                IRfcTable t_comiteTable = rfcFun.GetTable("T_DATA_COMITE");

                if (t_comiteTable.RowCount > 0)
                {
                    no_proyecto = Convert.ToString(t_comiteTable.GetValue("NO_PROYECTO"));
                    municipio = Convert.ToString(t_comiteTable.GetValue("MUNICIPIO"));
                    localidad = Convert.ToString(t_comiteTable.GetValue("LOCALIDAD"));
                    descripcion_proyecto = Convert.ToString(t_comiteTable.GetValue("DESCRIPCION_PROYECTO"));
                    programa = Convert.ToString(t_comiteTable.GetValue("PROGRAMA"));
                    no_comite = Convert.ToString(t_comiteTable.GetValue("NO_COMITE"));
                    nombre_comite = Convert.ToString(t_comiteTable.GetValue("NOMBRE_COMITE"));
                }
            }
            catch (Exception ex) { ex.Message.ToString(); }
        }

        public string SystemYear()
        {
            string year ;
            return year = Convert.ToString(DateTime.Now.Year);
        }

        public void IntegrantesComite(string id_caso)
        {
            try
            {
                RfcDestination rfcDest = RfcDestinationManager.GetDestination("SAP_CPR");
                RfcRepository rfcRep = rfcDest.Repository;
                IRfcFunction rfcFun = rfcRep.CreateFunction("Z_BAPIPRGCOMITES");

                rfcFun.SetValue("ID_CASO", id_caso);
                rfcFun.Invoke(rfcDest);

                IRfcTable t_comiteTable = rfcFun.GetTable("T_DATA_CIUDADANO");

                if (t_comiteTable.RowCount > 0)
                {
                        nombre_ciudadano = Convert.ToString(t_comiteTable.GetValue("NOMBRE_RESPONSABLE"));
                        puesto = Convert.ToString(t_comiteTable.GetValue("PUESTO"));                  
                }
            }
            catch (Exception ex) { ex.Message.ToString(); }
        }
    }
}