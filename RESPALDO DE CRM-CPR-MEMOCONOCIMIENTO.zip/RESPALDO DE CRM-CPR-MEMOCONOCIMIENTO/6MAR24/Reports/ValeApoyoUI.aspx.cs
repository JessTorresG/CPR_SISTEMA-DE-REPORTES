﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ptu02;
using ptu02.BO;
using ptu02.BAPI;
using System.Configuration;
using SAP.Middleware.Connector;

namespace PTU02_WEBREPORTS.Reports
{
    public partial class ValeApoyoUI : System.Web.UI.Page
    {
        //string letra = "V";
        //string nombre_usuario;
        //string val_description_uc;
        //string val_net_value_man;
        //string val_guid;

        public ValeApoyoViewClass CurrentViewClass
        {
            get { return this.ViewState["CurrentViewClass"] != null ? (ValeApoyoViewClass)this.ViewState["CurrentViewClass"] : null; }
            set { this.ViewState["CurrentViewClass"] = value; }
        }

        private string ObjectID
        {
            get;
            set;
        }

        private string Username
        {
            get;
            set;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
          
            try
            {
               //Aqui recibo el id de la petición
               ObjectID = this.Request.QueryString["OBJECT_ID"];
               //Aqui recibo el nombre del usuario quien está generando la petición.
               Username = this.Request.QueryString["USER"];
                           
                 if (!this.IsPostBack)
                 {
                     if (ObjectID != null)
                     {
                            #region Seguridad

                     string Corregido = string.Empty;
                     foreach (char item in ObjectID)
                     {
                         if (item != '?')
                             Corregido = Corregido + item;
                     }

                     ObjectID = Corregido;

                     ObjectID = Hash.UnHashNumber(ObjectID);


                     if (ObjectID.Length <= 14)
                     {
                         mviewReportes.Visible = false;
                         this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "Parametros incorrectos. Genere nuevamente el reporte");
                         return;
                     }
                     string fecha = ObjectID.Substring(0, 14);
                     fecha = fecha.Insert(4, "-").Insert(7, "-").Insert(10, " ").Insert(13, ":").Insert(16, ":");
                     DateTime FechaRecibida = DateTime.MinValue;

                     FechaRecibida = DateTime.Parse(fecha);
                     ObjectID = ObjectID.Substring(14, ObjectID.Length - 14);

                     if (!((DateTime.Now - FechaRecibida).Minutes >= 0 && (DateTime.Now - FechaRecibida).Minutes < Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutValidation"].ToString())))
                     {
                         mviewReportes.Visible = false;
                         this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "La sesión que intenta abrir ha expirado. Genere nuevamente el reporte");
                         return;
                     }

                     #endregion                    
                         this.mviewReportes.Visible = true;
                         this.CargarInformacion();
                         //this.CallFunction_ZZCRM_WAP_ORDER_READ();                   
                     } 
                     else
                     {
                         //ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "Error", "alert('La sesión que intenta abrir ha expirado. Genere nuevamente el reporte.'", true);
                         mviewReportes.Visible = false;
                         this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "Parametros incorrectos. Genere nuevamente el reporte");
                         return;
                     }
                                       
                 }

            }
            catch (Exception ex)
            {
                mviewReportes.Visible = false;
                this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", ex.Message);
                return;
            }

        }

        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            if (this.mviewReportes.Visible)
                switch (this.mviewReportes.ActiveViewIndex)
                {
                    case 0:
                        {
                            ScriptManager.RegisterStartupScript(
                                this,
                                this.GetType(),
                                Guid.NewGuid().ToString(),
                                "showPopUpSeleccionElementos(true);",
                                true
                            );
                        }
                        break;

                }
        }

        protected void btnAceptar_Click(Object sender, EventArgs e)
        {
            this.BindControls(this.CurrentViewClass);
            this.mviewReportes.ActiveViewIndex = 1;
        }

        //ObjectID = "6000000126";
        private void CargarInformacion()
        {
            this.CurrentViewClass = Services.ValeDeApoyoReporte(ObjectID);
            this.gv_FavorBrindar_Selection.DataSource = this.CurrentViewClass.Medicamentos;
            this.gv_FavorBrindar_Selection.DataBind();

            this.mviewReportes.ActiveViewIndex = 0;
        }

        private void BindControls(ValeApoyoViewClass bo)
        {
            this.lbl_Fecha.Text = bo.FechaString;
            this.lbl_NoVale.Text = bo.NoVale;
            
            //this.lbl_FavorBrindar.Text = bo.BrindarA;

            var source = bo.Medicamentos.AsEnumerable()
                            .Where(r => r.Field<Boolean>("Seleccionado"))
                            .Select(r => new
                            {
                                ID = r.Field<long>("ID"),
                                ////GUID = r.Field<String>("GUID"),
                                Cantidad = r.Field<Decimal>("Cantidad"),
                                Beneficio = r.Field<String>("Beneficio"),
                                Descripcion = r.Field<String>("Descripcion"),
                                Subtotal = r.Field<Decimal>("Subtotal")
                            })
                            .ToList();

            bo.Costo = source.Sum(o => o.Subtotal);

            this.gv_FavorBrindar.DataSource = source;
            this.gv_FavorBrindar.DataBind();
            this.gv_FavorBrindar.Columns[0].Visible = false;
            
            this.lbl_RFC.Text = bo.RFC;
            this.lbl_CURP.Text = bo.CURP;

            //ID = r.Field<long>("ID"),
            //this.lbl_Costo.Text = bo.Costo.ToString() + " " + bo.CostoLetras;
            this.lbl_Proveedor.Text = !String.IsNullOrEmpty(bo.Proveedor) ? bo.Proveedor : "NA";

            // Aqui los movi.
            this.lbl_Beneficiario.Text = !String.IsNullOrEmpty(bo.Beneficiario) ? bo.Beneficiario : "NA";
            this.lbl_Observaciones.Text = !String.IsNullOrEmpty(bo.Observaciones) ? bo.Observaciones : "NA";
        }

        protected void UpdateSelection()
        {
            for (int i = 0; i < this.gv_FavorBrindar_Selection.Rows.Count; i++)
            {
                GridViewRow gvRow = this.gv_FavorBrindar_Selection.Rows[i];
                CheckBox chk_Seleccionado = (CheckBox)gvRow.FindControl("chk_Seleccionado");
                HiddenField hdf_ID = (HiddenField)gvRow.FindControl("hdf_ID");

                DataRow row = this.CurrentViewClass.Medicamentos.AsEnumerable()
                                .Where(r => r.Field<long>("ID") == Convert.ToInt64(hdf_ID.Value))
                                .FirstOrDefault();

                if (row != null)
                    row.SetField<Boolean>("Seleccionado", chk_Seleccionado.Checked);
            }
        }

        protected void gv_FavorBrindar_Selection_Load(object sender, EventArgs e)
        {
            this.UpdateSelection();
        }


        //METODO EN ESPERA DE QUE SEA USADO
        //private void CallFunction_ZZCRM_WAP_ORDER_READ()
        //{
        //    try
        //    {
        //        RfcDestination rfcDest = RfcDestinationManager.GetDestination("SAP_CDV");
        //        RfcRepository rfcRep = rfcDest.Repository;
        //        IRfcFunction rfcFun = rfcRep.CreateFunction("ZZCRM_WAP_ORDER_READ");

        //        rfcFun.SetValue("I_OBJ_ID", ObjectID);
        //        rfcFun.SetValue("IV_IS_ITEM", "");
        //        rfcFun.SetValue("I_APOYO", letra);
        //        rfcFun.Invoke(rfcDest);

        //        string municipio;
        //        municipio = rfcFun.GetValue("E_MPIO").ToString();

        //        //Obtener el nombre del usuario quien esta imprimiendo el vale.
        //        nombre_usuario = rfcFun.GetValue("E_USUARIO").ToString(); ;

        //        //lbl_nombreUsuario.Text = nombre_usuario;
        //        lbl_nombreUsuario.Text = Username;

        //        if (municipio == "")
        //            lbl_Municipio.Text = "Cd. Victoria";
        //        else
        //            lbl_Municipio.Text = municipio;
        //    }
        //    catch (Exception e)
        //    {
        //        Response.Write(e.Message.ToString());
        //    }
        //}


        //METODO ES ESPERA DE QUE SEA USADO
        ////private void CallFunction_ZCRM_UPD_PROD_VAL_DIF()
        ////{
        ////    try
        ////    {
        ////        for (int i = 0; i < this.gv_FavorBrindar.Rows.Count; i++)
        ////        {
        ////            string date = DateTime.Today.ToString("yyyy MM dd");
        ////            date = date.Replace(" ", "");

        ////            RfcDestination rfcDest = RfcDestinationManager.GetDestination("SAP_CDV");
        ////            RfcRepository rfcRep = rfcDest.Repository;
        ////            IRfcFunction rfcFun = rfcRep.CreateFunction("ZCRM_UPD_PROD_VAL_DIF");               

        ////            rfcFun.SetValue("I_OPERACION", lbl_NoVale.Text); //Este valor si se envía.
        ////            rfcFun.SetValue("I_FECHA", date); //Este valor si se envía.
        ////            rfcFun.SetValue("I_NOM_BENF", lbl_Beneficiario.Text); //Este valor si se envía.
        ////            rfcFun.SetValue("I_CURP", lbl_CURP.Text); //Este valor si se envía.
        ////            //rfcFun.SetValue("I_DESC_APOYO", "prueba");
        ////            rfcFun.SetValue("I_OBS", lbl_Observaciones.Text.TrimEnd());
        ////            //rfcFun.SetValue("I_USUARIO", lbl_nombreUsuario.Text);
        ////            rfcFun.SetValue("I_USUARIO", "Fernando");

        ////            IRfcTable t_productosTable = rfcFun.GetTable("T_PRODUCTOS");
        ////            IRfcTable t_medicamentosTable = rfcFun.GetTable("T_MEDICAMENTOS");
        ////            IRfcStructure t_productosStructure = t_productosTable.Metadata.LineType.CreateStructure();
        ////            IRfcStructure t_medicamentosStructure = t_medicamentosTable.Metadata.LineType.CreateStructure();
                   
        ////            string guid;
        ////            double value_man;
        ////            string description_uc;

        ////            guid = gv_FavorBrindar.Rows[i].Cells[0].Text;
        ////            value_man = Convert.ToDouble(gv_FavorBrindar.Rows[i].Cells[1].Text);
        ////            description_uc = gv_FavorBrindar.Rows[i].Cells[2].Text;

        ////            //if (description_uc == " ")
        ////            //description_uc = "NA";

        ////            //PARA LA TABLA PRODUCTOS.
        ////            t_productosTable.Append();
        ////            t_productosTable.SetValue("GUID", guid);  //Este valor si se envía.
        ////            t_productosTable.SetValue("DESCRIPTION_UC", description_uc);  //Este valor si se envía.
        ////            t_productosTable.SetValue("NET_VALUE_MAN", value_man); //cantidad por producto  

        ////            //PARA LA TABLA MEDICAMENTOS.
        ////            t_medicamentosTable.Append();
        ////            t_medicamentosTable.SetValue("GUID", guid);  //Este valor si se envía.
        ////            t_medicamentosTable.SetValue("DESCRIPTION_UC", description_uc);  //Este valor si se envía.
        ////            t_medicamentosTable.SetValue("ORIG_ORDER_QTY", value_man); //cantidad por producto 
       
                    
        ////            //string guid1;
        ////            //double value_man1;
        ////            //string description_uc1;

        ////            //guid = gv_FavorBrindar.Rows[0].Cells[0].Text;
        ////            //value_man = Convert.ToDouble(gv_FavorBrindar.Rows[0].Cells[1].Text);
        ////            //description_uc = gv_FavorBrindar.Rows[0].Cells[2].Text;

        ////            //Response.Write(guid.ToString() + ", " + value_man + " ," + description_uc);
                 
        ////            RfcSessionManager.BeginContext(rfcDest);
        ////            rfcFun.Invoke(rfcDest);
        ////            RfcSessionManager.EndContext(rfcDest);     
        ////        }
        ////    }
        ////    catch (Exception e) { Response.Write(e.Message.ToString()); }
        ////}


        //METODO EN ESPERA DE QUE SEA USADO
        //private void SacarValoresGrid()
        //{
        //    string guid;
        //    double value_man;
        //    string description_uc;

        //    //for (int i = 0; i < this.gv_FavorBrindar.Rows.Count; i++)
        //    for (int i = 0; i <1; i++)
        //    {
        //        guid = gv_FavorBrindar.Rows[i].Cells[0].Text;
        //        value_man = Convert.ToDouble(gv_FavorBrindar.Rows[i].Cells[1].Text);
        //        description_uc = gv_FavorBrindar.Rows[i].Cells[2].Text;

        //        Response.Write(guid.ToString() + ", " + value_man + " ," + description_uc);
        //    }
        //    //string guid = gv_FavorBrindar.Rows[0].Cells[0].Text;
        //    //double value_man =Convert.ToDouble(gv_FavorBrindar.Rows[0].Cells[1].Text);
        //    //string description_uc = gv_FavorBrindar.Rows[0].Cells[2].Text;

        //    //double value_man = Convert.ToDouble(gv_FavorBrindar.Rows[this.gv_FavorBrindar.SelectedIndex].Cells[2]);
        //    //string description_uc = gv_FavorBrindar.Rows[this.gv_FavorBrindar.SelectedIndex].Cells[3].Text;           
        //}
   
        protected void btn_Imprimir_Click(object sender, EventArgs e)
        {        
            //CallFunction_ZCRM_UPD_PROD_VAL_DIF();
            //this.mviewReportes.ActiveViewIndex = 1;   
        }
        
    }
}