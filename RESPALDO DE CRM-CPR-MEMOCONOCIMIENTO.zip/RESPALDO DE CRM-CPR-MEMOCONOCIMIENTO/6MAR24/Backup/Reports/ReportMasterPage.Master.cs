﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace PTU02_WEBREPORTS.Reports
{
    public partial class ReportMasterPage : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.RegisterScripts();
        }

        /// <summary>
        /// Registra scripts base en el cabecero de la página HTML en curso
        /// </summary>
        private void RegisterScripts()
        {
            String[] scripts = new String[] {            
            "~/Scripts/jquery-1.4.1.min.js",
            "~/Scripts/jquery.blockUI.js"            
        };

            HttpContext currentContext = HttpContext.Current;
            for (int i = 0; i < scripts.Length; i++)
            {
                String script = scripts[i];
                if (currentContext.Items[script.ToUpper()] != null)
                    continue;

                HtmlGenericControl javaScriptControl = new HtmlGenericControl("script");
                javaScriptControl.Attributes["type"] = "text/javascript";
                javaScriptControl.Attributes["src"] = this.ResolveClientUrl(script);

                this.Page.Header.Controls.AddAt(i, javaScriptControl);
                currentContext.Items[script.ToUpper()] = true;
            }
        }
    }
}