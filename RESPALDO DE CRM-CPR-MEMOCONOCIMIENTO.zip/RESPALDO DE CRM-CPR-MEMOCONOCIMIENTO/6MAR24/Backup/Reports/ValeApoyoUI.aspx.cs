﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ptu02;
using ptu02.BO;

namespace PTU02_WEBREPORTS.Reports
{
    public partial class ValeApoyoUI : System.Web.UI.Page
    {
        public ValeApoyoViewClass CurrentViewClass
        {
            get { return this.ViewState["CurrentViewClass"] != null ? (ValeApoyoViewClass)this.ViewState["CurrentViewClass"] : null; }
            set { this.ViewState["CurrentViewClass"] = value; }
        }

        private string ObjectID
        {
            get { return this.Request.QueryString["OBJECT_ID"]; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                if (ObjectID != null)
                {
                    this.mviewReportes.Visible = true;
                    this.CargarInformacion();
                }
            }
        }

        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            if (this.mviewReportes.Visible)
                switch (this.mviewReportes.ActiveViewIndex)
                {
                    case 0:
                        {
                            ScriptManager.RegisterStartupScript(
                                this,
                                this.GetType(),
                                Guid.NewGuid().ToString(),
                                "showPopUpSeleccionElementos(true);",
                                true
                            );
                        }
                        break;

                }
        }

        protected void btnAceptar_Click(Object sender, EventArgs e)
        {
            this.BindControls(this.CurrentViewClass);
            this.mviewReportes.ActiveViewIndex = 1;
        }

        private void CargarInformacion()
        {
            this.CurrentViewClass = Services.ValeDeApoyoReporte(ObjectID);
            this.gv_FavorBrindar_Selection.DataSource = this.CurrentViewClass.Medicamentos;
            this.gv_FavorBrindar_Selection.DataBind();

            this.mviewReportes.ActiveViewIndex = 0;
        }

        private void BindControls(ValeApoyoViewClass bo)
        {
            this.lbl_Fecha.Text = bo.Fecha.ToShortDateString();
            this.lbl_NoVale.Text = bo.NoVale;
            this.lbl_Beneficiario.Text = !String.IsNullOrEmpty(bo.Beneficiario) ? bo.Beneficiario : "NA";
            this.lbl_Observaciones.Text = !String.IsNullOrEmpty(bo.Observaciones) ? bo.Observaciones : "NA";
            //this.lbl_FavorBrindar.Text = bo.BrindarA;

            var source = bo.Medicamentos.AsEnumerable()
                            .Where(r => r.Field<Boolean>("Seleccionado"))
                            .Select(r => new
                            {
                                Cantidad = r.Field<Decimal>("Cantidad"),
                                Beneficio = r.Field<String>("Beneficio"),
                                Descripcion = r.Field<String>("Descripcion"),
                                Subtotal = r.Field<Decimal>("Subtotal")
                            })
                            .ToList();

            bo.Costo = source.Sum(o => o.Subtotal);           

            this.gv_FavorBrindar.DataSource = source;
            this.gv_FavorBrindar.DataBind();

            this.lbl_Costo.Text = bo.Costo.ToString();
            this.lbl_Proveedor.Text = !String.IsNullOrEmpty(bo.Proveedor) ? bo.Proveedor : "NA";
        }

        protected void UpdateSelection()
        {
            for (int i = 0; i < this.gv_FavorBrindar_Selection.Rows.Count; i++)
            {
                GridViewRow gvRow = this.gv_FavorBrindar_Selection.Rows[i];
                CheckBox chk_Seleccionado = (CheckBox)gvRow.FindControl("chk_Seleccionado");
                HiddenField hdf_ID = (HiddenField)gvRow.FindControl("hdf_ID");                

                DataRow row = this.CurrentViewClass.Medicamentos.AsEnumerable()
                                .Where(r => r.Field<long>("ID") == Convert.ToInt64(hdf_ID.Value))
                                .FirstOrDefault();

                if (row != null)
                    row.SetField<Boolean>("Seleccionado", chk_Seleccionado.Checked);
            }
        }

        protected void gv_FavorBrindar_Selection_Load(object sender, EventArgs e)
        {
            this.UpdateSelection();
        }        
    }
}