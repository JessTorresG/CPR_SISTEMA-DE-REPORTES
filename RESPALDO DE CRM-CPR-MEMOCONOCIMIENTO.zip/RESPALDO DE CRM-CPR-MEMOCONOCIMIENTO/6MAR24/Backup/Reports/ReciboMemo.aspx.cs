﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ptu02.BO;
using ptu02;

namespace PTU02_WEBREPORTS.Reports
{
    public partial class ReciboMemo : System.Web.UI.Page
    {
        public String DocumentID
        {
            get
            {
                return this.Request.QueryString["OBJECT_ID"];
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack && this.DocumentID != null)
                this.CargarInformacion();
        }

        private void CargarInformacion()
        {
            ReciboMemoViewClass bo = Services.ReporteReciboMemo(this.DocumentID);

            this.lblMemoNo.Text = bo.NoSolicitud;
            //this.lblBeneficiario.Text = bo.Beneficiario;
            //this.lblConcepto.Text = bo.Concepto;
            //this.lblCantidad.Text = bo.Cantidad.ToString() + " " + bo.cantidadLetras;
            //this.lblDomicilio.Text = bo.Direccion;
            this.lbl_DirectorOficinasEjecutivoEstatalNombre.Text = bo.DirectorOficinasEjecutivoEstatalNombre;

            this.lblFecha.Text = bo.Fecha.ToShortDateString();
            this.lblTipoApoyo.Text = bo.TipoDeApoyo;

            this.lbl_DirGenRelaciones.Text = bo.lbl_DirGenRelaciones;

            this.lbl_Beneficiario.Text = "Por este conducto me permito solicitar a usted apoyo para la C. " +
                    "<span class='campo_2'> " + bo.Beneficiario + " </span>" +
                    "la cantidad de $ " +
                    "<span class='campo_2' >" + bo.Cantidad.ToString() + " (" + bo.cantidadLetras + ") </span> " +
                    "por concepto de " +
                    "<span class='campo_2' >" + bo.Concepto + " </span> " +
                    "la cual manifestó no contar con los recursos económicos y tener su domicilio: " +
                    "<span class='campo_2' >" + bo.Direccion + " </span>.";
        }
    }
}