﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ptu02.BO;
using System.Collections;

namespace PTU02_WEBREPORTS.Reports
{
    public partial class QuejasRecomendacionesUI : System.Web.UI.Page
    {
        public String NumID
        {
            get
            {
                return this.Request.QueryString["BOR_KEY"];
            }
        }

        public String QuejaID
        {
            get
            {
                return this.Request.QueryString["ZHDQ"];
            }
        }

        public String RecomendacionID
        {
            get
            {
                return this.Request.QueryString["ZHDR"];
            }
        }

        public String MedidaID
        {
            get
            {
                return this.Request.QueryString["ZHDM"];
            }
        }

        public String UsuarioID
        {
            get
            {
                return this.Request.QueryString["USER"];
            }
        }       

        public String SelectedReportType
        {
            get { return this.ViewState["SelectedReportType"] != null ? this.ViewState["SelectedReportType"].ToString() : null; }
            set { this.ViewState["SelectedReportType"] = value; }
        }

        public QuejasRecomendacionesViewClass CurrentViewClass
        {
            get { return this.ViewState["CurrentViewClass"] != null ? (QuejasRecomendacionesViewClass)this.ViewState["CurrentViewClass"] : null; }
            set { this.ViewState["CurrentViewClass"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.NumID == null)
                return;

            this.mviewReportes.Visible = true;
            if (!this.IsPostBack)
            {                
                if (this.QuejaID == null)
                    this.rbtnList.Items.Remove(this.rbtnList.Items.FindByValue("ZHDQ"));

                if (this.RecomendacionID == null)
                    this.rbtnList.Items.Remove(this.rbtnList.Items.FindByValue("ZHDR"));

                if (this.MedidaID == null)
                    this.rbtnList.Items.Remove(this.rbtnList.Items.FindByValue("ZHDM"));

                if (this.rbtnList.Items.Count > 0)
                {
                    this.rbtnList.SelectedIndex = 0;

                    if (this.rbtnList.Items.Count > 1)
                        this.mviewReportes.ActiveViewIndex = 0;
                    else
                        this.SelectedReportType = this.rbtnList.Items[0].Value;
                }

                if (this.SelectedReportType != null)
                    this.CargarInformacion();
            }           
        }

        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            if (this.mviewReportes.Visible)
                switch (this.mviewReportes.ActiveViewIndex)
                {
                    case 0:
                        {
                            ScriptManager.RegisterStartupScript(
                                this,
                                this.GetType(),
                                Guid.NewGuid().ToString(),
                                "showPopUpTipoReporte(true);",
                                true
                            );
                        }
                        break;
                    case 1:
                        {
                            ScriptManager.RegisterStartupScript(
                                this,
                                this.GetType(),
                                Guid.NewGuid().ToString(),
                                "showPopUpReportesDisponibles(true);",
                                true
                            );
                        }
                        break;
                }
        }        

        private void CargarInformacion()
        {
            String queja = this.SelectedReportType == "ZHDQ" ? this.QuejaID : null;
            String recomendacion = this.SelectedReportType == "ZHDR" ? this.RecomendacionID : null;
            String medida = this.SelectedReportType == "ZHDM" ? this.MedidaID : null;

            List<IDictionary> idControlList = new List<IDictionary>();
            this.CurrentViewClass = ptu02.Services.ReporteQuejasRecomendaciones(this.CurrentViewClass, idControlList, this.NumID, queja, recomendacion, medida, this.UsuarioID);

            if (!String.IsNullOrEmpty(this.CurrentViewClass.IDControl))
            {                
                this.mviewReportes.ActiveViewIndex = 2;
                this.BindControls(this.CurrentViewClass);
            }
            else
            {
                if (idControlList.Count > 0)
                {
                    this.mviewReportes.ActiveViewIndex = 1;
                    this.rbtNumerosControl.DataSource = idControlList
                                                            .Select(i => new { Value = i["BOR_KEY"], Text = i["OBJECT_ID"] })
                                                            .ToList();
                    this.rbtNumerosControl.DataBind();
                    this.rbtNumerosControl.SelectedIndex = 0;
                }
            }
        }

        private void BindControls(QuejasRecomendacionesViewClass bo)
        {
            this.lbl_TipoHistorial.Text = bo.TipoHistorial;
            this.lbl_IdBeneficiario.Text = bo.IDControl;
            this.lbl_NombreBeneficiario.Text = bo.NombreBeneficiario;
            this.lbl_IdControl.Text = bo.IDControl;
            this.lbl_Comision.Text = bo.NombreComision;
            this.lbl_FechaRecepción.Text = bo.FechaRecepcion.ToShortDateString();
            this.lbl_Beneficiario.Text = bo.NombreBeneficiario;
            this.lbl_Motivo.Text = bo.Motivo;
            this.lbl_AutoridadResponsable.Text = bo.AutoridadResponsable;
            this.lbl_Dependencia.Text = bo.Dependencia;
            this.lbl_SituacionActual.Text = bo.SituacionActual;
            this.lbl_Dia.Text = bo.Dia.ToShortDateString();
            this.lbl_Asunto.Text = bo.Asunto;
            this.lbl_NombreUsuario.Text = bo.NombreUsuario;
        }

        protected void btnAceptarTipoReporte_Click(object sender, EventArgs e)
        {
            this.SelectedReportType = this.rbtnList.SelectedItem.Value;
            this.CargarInformacion();
        }

        protected void btnAceptar_Click(object sender, EventArgs e)
        {
            this.CurrentViewClass.BorKey = this.rbtNumerosControl.SelectedItem.Value;
            this.CurrentViewClass.IDControl = this.rbtNumerosControl.SelectedItem.Text;
            this.CargarInformacion();
        }
    }
}