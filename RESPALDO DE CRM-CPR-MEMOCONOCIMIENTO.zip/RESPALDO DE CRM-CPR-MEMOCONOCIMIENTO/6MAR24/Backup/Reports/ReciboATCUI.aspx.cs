﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ptu02.BO;

namespace PTU02_WEBREPORTS.Reports
{
    public partial class ReciboATCUI : System.Web.UI.Page
    {
        private string l_NumID = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                l_NumID = Request.QueryString["OBJECT_ID"];
            }
            if (l_NumID != null)
                CargarInformacion();
        }

        private void CargarInformacion()
        {
            ReciboViewClass bo = ptu02.Services.MetodoReporte(l_NumID);

            this.lbl_Solicitud.Text = l_NumID;
            this.lbl_Fecha.Text = bo.Fecha.ToShortDateString();
            //this.lbl_ApoyoConcepto.Text = bo.cantidad.ToString() + " " + bo.cantidadLetras;
            //this.lbl_Concepto.Text = bo.Concepto;
            this.lbl_NombreBP.Text = bo.NombreBP;
            this.lbl_DomicilioBP.Text = bo.DireccionBP;
            this.lbl_MunicipioBP.Text = bo.MunicipioBP;
            this.lbl_TipoÁpoyo.Text = bo.TipoDeApoyo;

            this.lbl_Contendio.Text = "Recib&iacute; de la Secretaría de Finanzas del gobierno "+
                "del Estado de Tamaulipas, a través de la <strong>Dirección General de Relaciones Públicas, "+
                "Compromisos y Atención Ciudadana</strong> como apoyo: $ <span class=campo_2>" +
                bo.cantidad.ToString() + " (" + bo.cantidadLetras + ")</span> " +
                "por concepto de " + "<span class=campo_2>" + bo.Concepto + "</span> " +
                "manifestando no contar con los recursos económicos.";
        }
    }
}