﻿
function showPrompt() {
    var peticion = prompt("Tecla el número de petición para confirmar la impresión! Gracias.")

    if (peticion != null && peticion != "") {
        alert("Tu petición es: " + peticion);
        ImprimirPage();
        
    }
}

function ImprimirPage() {
    window.print();
}

function InvocarMetodo() {

}

function url() {
    hidden = open('~/Reports/confirm.aspx', 'NewWindow', 'top=300,left=-200,right=500,width=600,height=200,status=yes,resizable=yes,scrollbars=yes');
        }

        function CerrarVentana() {
            window.close();
        }


function cerrarpagina() {

            window.close();
            return false;
        }

        function imprimirForm() {
            if (window.print() == true)
                CerrarVentana();
        }