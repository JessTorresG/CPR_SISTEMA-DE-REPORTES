﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ptu02.BO;
using System.Configuration;

namespace PTU02_WEBREPORTS.Reports
{
    public partial class SancionServicioPublicoUI : System.Web.UI.Page
    {
        private string l_NumID = "";
        private string l_PARTNER = "";
        private string l_EXT_KEY = "";

        private string v_NombreAutoridad
        {
            get { return Convert.ToString(ViewState["NombreAutoridad"]); }
            set { ViewState["NombreAutoridad"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsPostBack)
                {
                    l_NumID = Request.QueryString["OBJECT_ID"];
                    l_PARTNER = Request.QueryString["PARTNER"];
                    l_EXT_KEY = Request.QueryString["EXT_KEY"];


                    if (!String.IsNullOrEmpty(l_NumID) && !String.IsNullOrEmpty(l_PARTNER) && !String.IsNullOrEmpty(l_EXT_KEY))
                    {
                        #region Seguridad

                        string Corregido = string.Empty;
                        foreach (char item in l_NumID)
                        {
                            if (item != '?')
                                Corregido = Corregido + item;
                        }

                        l_NumID = Corregido;

                        l_NumID = Hash.UnHashNumber(l_NumID);
                        l_PARTNER = Hash.UnHashNumber(l_PARTNER);
                        l_EXT_KEY = Hash.UnHashNumber(l_EXT_KEY);

                        if (l_NumID.Length <= 14)
                        {
                            tbl_datos.Visible = false;
                            this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "Parametros incorrectos. Genere nuevamente el reporte");
                            return;
                        }
                        string fecha = l_NumID.Substring(0, 14);
                        fecha = fecha.Insert(4, "-").Insert(7, "-").Insert(10, " ").Insert(13, ":").Insert(16, ":");
                        DateTime FechaRecibida = DateTime.MinValue;

                        FechaRecibida = DateTime.Parse(fecha);
                        l_NumID = l_NumID.Substring(14, l_NumID.Length - 14);

                        if (!((DateTime.Now - FechaRecibida).Minutes >= 0 && (DateTime.Now - FechaRecibida).Minutes < Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutValidation"].ToString())))
                        {
                            tbl_datos.Visible = false;
                            this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "La sesión que intenta abrir ha expirado. Genere nuevamente el reporte");
                            return;
                        }

                        #endregion

                        v_NombreAutoridad = this.hdn_Sancionador.Value;

                        CargarInformacion();
                    }
                    else
                    {
                        //ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "Error", "alert('La sesión que intenta abrir ha expirado. Genere nuevamente el reporte.'", true);
                        tbl_datos.Visible = false;
                        this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "Parametros incorrectos. Genere nuevamente el reporte");
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                tbl_datos.Visible = false;
                this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", ex.Message);
                return;
            }
        }

        private void CargarInformacion()
        {
            RegistroSancionViewClass bo = ptu02.Services.SancionReporte(l_NumID, l_PARTNER, l_EXT_KEY);
            bo.NombreAutoridad = v_NombreAutoridad;

            this.lbl_RFCHomoclave.Text = bo.RFC;
            this.lbl_Nombre.Text = bo.Nombre;
            this.lbl_Puesto.Text = bo.Puesto;
            this.lbl_DependenciaOEntidad.Text = bo.Dependencia;
            this.lbl_FechaResolucion.Text = (bo.FechaResolucion.HasValue) ? bo.FechaResolucion.Value.ToShortDateString() : "No proporcionada";
            this.lbl_FechaNotificacion.Text = (bo.FechaNotificacion.HasValue) ? bo.FechaNotificacion.Value.ToShortDateString() : "No proporcionada";
            this.lbl_FechaEjecutoriado.Text = (bo.FechaEjecutoriado.HasValue) ? bo.FechaEjecutoriado.Value.ToShortDateString() : "No proporcionada";
            this.lbl_FechaHechos.Text = (bo.FechaHechos.HasValue) ? bo.FechaHechos.Value.ToShortDateString() : "No proporcionada";
            this.rdb_DanoPatrimonial.SelectedIndex = (bo.DanoPatrimonial) ? 0 : 1;
            this.lbl_MontoDano.Text = bo.MontoDelDano;
            this.lbl_Sancion1.Text = bo.Sancion1;
            this.lbl_Sancion2.Text = bo.Sancion2;
            this.lbl_Sancion3.Text = bo.Sancion3;
            this.lbl_Monto.Text = bo.Monto.ToString();
            this.rdb_Mayor100.SelectedIndex = (bo.Mayor100 == "X") ? 0 : 1;
            this.lbl_Duracion.Text = bo.Duracion;
            this.lbl_FechaInicio.Text = (bo.FechaInicio.HasValue) ? bo.FechaInicio.Value.ToShortDateString() : "No proporcionada";
            this.lbl_FechaTerminacion.Text = (bo.FechaTerminacion.HasValue) ? bo.FechaTerminacion.Value.ToShortDateString() : "No proporcionada";
            this.lbl_AutoridadSancionada.Text = bo.Autoridad;
            this.lbl_ExpedienteNo.Text = bo.Expediente;
            this.lbl_Origen.Text = bo.Origen;
            this.lbl_Irregularidad.Text = bo.Irregularidad;
            this.lbl_Hechos.Text = bo.Hechos;
            this.lbl_NombreAutoridad.Text = bo.NombreAutoridad;
        }
    }
}