﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ptu02.BO;
using ptu02.BAPI;
using ptu02;
using System.Configuration;
using SAP.Middleware.Connector;


namespace PTU02_WEBREPORTS.Reports
{
    public partial class ReciboATCUI : System.Web.UI.Page
    {

        public string l_NumID = "";
        public string nombre_usuario="";
        public string id_solicitud = "";
        public string letra = ""; //le agregué las ""

        //Agregue el 06-10-2014
        public ValeApoyoViewClass CurrentViewClass
        {
            get { return this.ViewState["CurrentViewClass"] != null ? (ValeApoyoViewClass)this.ViewState["CurrentViewClass"] : null; }
            set { this.ViewState["CurrentViewClass"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //if (!Page.IsPostBack)
                //{
                    l_NumID = Request.QueryString["OBJECT_ID"];
                    //nombre_usuario= Request.QueryString["USER"];
                   
                    letra = "R";
                   
                    if (String.IsNullOrEmpty(l_NumID))
                    {
                        //ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "Error", "alert('La sesión que intenta abrir ha expirado. Genere nuevamente el reporte.'", true);
                        tbl_datos.Visible = false;

                    this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "Parametros incorrectos. Genere nuevamente el reporte");
                    return;
                    }

                    #region Seguridad

                    string Corregido = string.Empty;
                    foreach (char item in l_NumID)
                    {
                        if (item != '?')
                            Corregido = Corregido + item;
                    }

                    l_NumID = Corregido;
                    l_NumID = Hash.UnHashNumber(l_NumID);
                    if (l_NumID.Length <= 14)
                    {
                    tbl_datos.Visible = false;
                    this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "Parametros incorrectos. Genere nuevamente el reporte");
                    return;
                }
                    string fecha = l_NumID.Substring(0, 14);
                    fecha = fecha.Insert(4, "-").Insert(7, "-").Insert(10, " ").Insert(13, ":").Insert(16, ":");
                    DateTime FechaRecibida = DateTime.MinValue;

                    FechaRecibida = DateTime.Parse(fecha);
                    l_NumID = l_NumID.Substring(14, l_NumID.Length - 14);

                    if (!((DateTime.Now - FechaRecibida).Minutes >= 0 && (DateTime.Now - FechaRecibida).Minutes < Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutValidation"].ToString())))
                    {
                        //ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "Error", "alert('La sesión que intenta abrir ha expirado. Genere nuevamente el reporte.'", true);
                        
                        tbl_datos.Visible = false;
                    this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", "La sesión que intenta abrir ha expirado. Genere nuevamente el reporte");
                    //return;
                }

                    #endregion

                    string l_imagen = Request.QueryString["IMAGEN"];

                    //Response.Write("<script>alert('IMAGEN= " + l_imagen + "');</script>");

                    if (!String.IsNullOrEmpty(l_imagen) && l_imagen == "NO")
                    {
                        this.img_logo.Visible = false;
                        //this.img_logo2.Visible = false;
                    }
                //}

                if (l_NumID != null)
                {
                    CargarInformacion();
                    ZCRM_ATC_READATOS_RECIBO();
                }
                          
            }
            catch (Exception ex)
            {
                tbl_datos.Visible = false;
                this.ltrError.Text = String.Format("<span style=\"color:Red\" class=\"espacio_grande\">{0}</span>", ex.ToString());
                return;
            }
        }   

        private void CargarInformacion()
                {
                    ReciboViewClass bo = ptu02.Services.MetodoReporte(l_NumID);
                    
                    //Agregue el 06-10-2014
                    this.CurrentViewClass = Services.ValeDeApoyoReporte(l_NumID);
                    this.BindControls(this.CurrentViewClass);

            //this.lbl_Solicitud.Text = l_NumID;
                    this.lbl_Solicitud.Text = bo.NoSolicitud;
                    this.fecha_actual.Text = DateTime.Now.ToLongDateString();

            //this.lbl_Fecha.Text = DateTime.Now.ToString();
                    this.lbl_NombreBP.Text = bo.NombreBP.ToUpper();
                    this.lbl_DomicilioBP.Text = bo.DireccionBP.ToUpper();
                    this.lbl_Telefono.Text = bo.TelefonoBP;

                    //this.lbl_MunicipioBP.Text = bo.MunicipioBP;
                    //this.lbl_TipoÁpoyo.Text = bo.TipoDeApoyo;

                         this.lbl_Contendio.Text = "Recibi&oacute; de la Dirección General de Relaciones Públicas, Compromisos y" +
                        " Atención Ciudadana, <strong>" + bo.Concepto + 
                        "por la cantidad de: $ " + bo.cantidad.ToString() +
                        " (" + bo.cantidadLetras + ")" + ", manifestando no contar con los recursos económicos. </strong>"; 
                }

        private void BindControls(ValeApoyoViewClass bo)
        {
  
            this.lbl_curp.Text = bo.CURP;
            //this.lbl_Telefono.Text = bo.TelefonoBP;

        }

        protected void btn_imprimir_Click(object sender, EventArgs e)
        {

        }
        
        //metodo en espera de que sea usado
        //public void ZCRM_UPD_APOYOS_METHOD()
        //{
        //    try
        //    {
        //        RfcDestination rfcDest = RfcDestinationManager.GetDestination("SAP_CDV");
        //        RfcRepository rfcRep = rfcDest.Repository;
        //        IRfcFunction rfcFun = rfcRep.CreateFunction("ZCRM_UPD_APOYOS");

        //        rfcFun.SetValue("I_OBJ_ID",lbl_Solicitud.Text);
        //        rfcFun.SetValue("I_APOYO",letra);
        //        //rfcFun.SetValue("I_USUARIO", nombre_usuario);
        
        //        rfcFun.Invoke(rfcDest);

        //        string e_mns = rfcFun.GetValue("E_MNS").ToString();
                       
        //      }
        //    catch (Exception e) { Response.Write(e.Message.ToString()); }        
        //  }

        //METODO EN ESPERA DE QUE SEA USADO
        //public void EjecutarFuncionOrderRead()
        //{
        //    try
        //    {
        //        RfcDestination rfcDest = RfcDestinationManager.GetDestination("SAP_CDV");
        //        RfcRepository rfcRep = rfcDest.Repository;
        //        IRfcFunction rfcFun = rfcRep.CreateFunction("ZZCRM_WAP_ORDER_READ");

        //        rfcFun.SetValue("I_OBJ_ID", l_NumID);
        //        rfcFun.SetValue("IV_IS_ITEM", "");
        //        rfcFun.SetValue("I_APOYO", letra);

        //        rfcFun.Invoke(rfcDest);
                
        //        lbl_folio.Text = rfcFun.GetValue("E_FOLIO").ToString();
        //        lbl_Fecha.Text = rfcFun.GetValue("E_FIMP").ToString();
        //        lbl_msjExcepcion_tratamiento.Text = rfcFun.GetValue("E_MNS").ToString();
        //    }
        //    catch (Exception e)
        //    {
        //        Response.Write(e.Message.ToString());
        //    }
        //}

        public void ZCRM_ATC_READATOS_RECIBO()
        {
            try
            {
                RfcDestination rfcDest = RfcDestinationManager.GetDestination("SAP_CPR");
                RfcRepository rfcRep = rfcDest.Repository;
                IRfcFunction rfcFun = rfcRep.CreateFunction("ZCRM_ATC_READATOS_RECIBO");

                rfcFun.SetValue("OBJ_ID", l_NumID);
                rfcFun.Invoke(rfcDest);

                //DateTime fecha = Convert.ToDateTime(rfcFun.GetValue("FECHA_MS").ToString());
                //string date = fecha.ToString("dd MM yyyy");
                //date = date.Replace(" ", "/");
                //lbl_Fecha.Text = date;
            }
            catch (Exception e)
            {
                Response.Write(e.Message.ToString());
            }
        }
    }
}